package com.example.logingianny_200545;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText ed1 = findViewById(R.id.usuario);
        EditText ed2 = findViewById(R.id.password);

        Button Star = findViewById(R.id.Button1);
        Button Clear = findViewById(R.id.Button2);

        Star.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String User = ed1.getText().toString();
                String Password = ed2.getText().toString();
                if(User.equals("root") && Password.equals("1234")){ enter();
                    Toast.makeText(getApplicationContext(), "Redirecting...", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(getApplicationContext(), "Wrong Credentials", Toast.LENGTH_SHORT).show();
                }
            }
        });

        Clear.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                String tx1 = ed1.getText().toString();
                String tx2 = ed2.getText().toString();

                if(tx1.isEmpty() && tx2.isEmpty()){
                    Toast.makeText(getApplicationContext(), "Contenido vaciado", Toast.LENGTH_SHORT).show();
                }
                else{
                     ed1.setText("");
                     ed2.setText("");
                }
            }
        });
    }

    public void enter (){
        Intent i = new Intent(this, MainActivity2.class);
        startActivity(i);
    }

}